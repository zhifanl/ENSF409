import javax.swing.plaf.basic.BasicComboBoxUI.ItemHandler;

/*
   INSTRUCTIONS: Implement all the members for which stubs are provided.

   You may not modify (change arguments, change permissions, etc) any of the
   stubs provided. You may only add to the code.

   You may modify class Marketplace, which is included for testing purposes only.
   It will not be graded. Your file must contain a public class Marketplace and be
   able to be compiled on the command-line, just like your assignments. All code
   must be included in a single file named Marketplace.java

   Include your name and student ID at the top of the file, as comments or
   documentation. We will not otherwise evaluate the program for comments/
   documentation.

   Other tips:
   1. Output should match what is shown in the example.
   2. You may assume that we will only test with valid data in the format
       shown in exampleData(), but we will not use the same data to test.
   3. You may add any additional private methods and data that you like.
   4. Do not include a package declaration!
   5. The code can be completed using concepts used already in class.
      You may need to include some libraries we have previously introduced.
   6. You may assume that there will never be more than 20 items, and that
      there will not be any categories other than the ones included in the
      example data (garden, kitchen, bedRoom, office, other).
   7. We will test the following methods:
          formatString(String key, String value)
          ListedItem(String[] array) 
          priceToString() 
          priceToString(double price) 
          setDate(String date) 
          getDate() 
          getCategory() 
          getItem() 
          getPrice() 
          AllListings(String[][] listings) 
          getItems() 
          formatCategory() 
          mixedcase(String word)         
*/

abstract class FormatWord {
 

    public abstract String mixedcase(String word); 

}

abstract class FormatOutput extends FormatWord {
    // Returns a string in the format of:
    // key - value
    public static String formatString(String key, String value) {   
        return key+=" - "+value;
    }

    // Returns a modified version of the original string where every other
    // letter is capital, and the others are lowercase, starting with the first
    // letter capital. E.g., with input 'WORD' the output is 'WoRd'
    public String mixedcase(String word) {
        StringBuilder string=new StringBuilder();
        for(int i=0;i<word.length();i++){
           // if(word.charAt(i)>=78||word.charAt(i)<=126){
            if(i%2==1){
                string.append(Character.toLowerCase(word.charAt(i)));
            }
            if(i%2!=1){
                string.append(Character.toUpperCase(word.charAt(i)));
            }

        }
        //else{string.append(word.charAt(i));}
    
    return string.toString();
    }   
}
class ListedItem extends FormatOutput {
    private String item;
    private double price;
    private String date;
    private String category;

    // Constructor
    public ListedItem(String[] array) {
        this.date=array[0];
        this.category=array[1];
        this.item=array[2];
        String a=array[3].substring(1);
        this.price=Double.valueOf(a);
        
    }

    // Returns this.price as a String with $ and cents.
    // E.g., if this.price is 40.5, it returns "$40.50"
    public String priceToString() {
        StringBuilder string=new StringBuilder("$");
        string.append(Double.toString(this.price));
        string.append("0");
        return string.toString();
    }

    // Returns the specified double price as a String with $ and cents.
    // E.g., if given 101.0, it returns "$101.00"    
    public static String priceToString(double price) {
        StringBuilder string=new StringBuilder("$");
        string.append(Double.toString(price));
        
        string.append("0");
        return string.toString();
    }

    // Setter
    
    public void setDate(String date) {
        this.date=date;
    }

    // Getter
    public String getDate() {
        return this.date;
    }

    // Getter
    public String getCategory() {
        return this.category;
    }

    // Getter
    public String getItem() {
        return this.item;
    }

    // Getter
    public double getPrice() {
        return this.price;
    }

}

class AllListings extends FormatOutput {
    private ListedItem[] listings;
    // Constructor
    public AllListings(String[][] listings) {
        this.listings=new ListedItem[listings.length];
        for(int i=0;i<listings.length;i++){
            this.listings[i]=new ListedItem(listings[i]);
        }
    }


    // Getter
    public ListedItem[] getItems() {
        return listings;
    }

    // Creates a legible String of all item listings, ordered by category.
    // Categories are listed in alphabetical order. All categories are
    // included, even if there are no items in that category. Each category
    // is listed on its own line, followed by a newline (the String "\n").
    // Each category is output in mixedcase() format.
    // Each item is listed on its own line, with ": " before it. Format of
    // each line is shown in example output. Note that the price is shown
    // with the $ and cents. There is no newline at the end of the String.
    // There are no empty lines in the output.
    public String formatCategory() {
        listings=sort(listings);
        StringBuilder sb=new StringBuilder();
        for(int i=0;i<listings.length;i++){
            sb.append(listings[i].mixedcase(listings[i].getCategory())+": "+listings[i].getItem()+" "+listings[i].priceToString());
            if(i!=listings.length-1)sb.append("\n");
        }
            
        
        return sb.toString();

    }
    private ListedItem[] sort(ListedItem[] a){
        for(int i=a.length-1;i>=0;i--){
            for(int j=0;j<i;j++){
                if((a[j].getCategory().compareTo(a[j+1].getCategory()))>0){
                    ListedItem temp=a[j];
                    a[j]=a[j+1];
                    a[j+1]=temp;

                }

            }
        }
        return a;
    }
}

public class Marketplace {
    public static void main(String args[]) {
        var data = exampleData();

        // Create an AllListings object. Order of listings is
        // the same as input data
        var allItems = new AllListings(data);

        // Demonstrate formatCategory(). Order is by category (alphabetical),
        // then by the order in the original data.
        System.out.println(allItems.formatCategory());
        // Add a blank line before the next output - formatCategory()
        // does not end with a newline character.
        System.out.println();

        // Retrieve the array of ListedItem objects from AllListings,
        // demonstrate a getter on one ListedItem
        var array = allItems.getItems();
        System.out.println(array[6].getItem());

        // Demonstrate the ListedItem constructor
        var myListing = new ListedItem(data[5]);

        // Demonstrate mixedcase
        System.out.println(myListing.mixedcase("This line of text is now mixed case")); 
        
        // Demonstrate priceToString, getString, formatString
        System.out.println("getPrice - " + myListing.getPrice() + "\npriceToString - " + myListing.priceToString());
        double tmpValue = 80.2;
       System.out.println(myListing.formatString("Input", Double.toString(tmpValue)));
        System.out.println(myListing.formatString("Input", ListedItem.priceToString(tmpValue)));
        System.out.println(AllListings.formatString("key", "value"));
    }

    // Each line is: posting date, category, item, price
    // Two lines have been commented out to demonstrate what an empty category looks
    // like with formatCategory(). You can expect that the real data could include
    // items in the category "office".
    public static String[][] exampleData() {
        String[][] example = {
            { "2021-01-30", "garden", "lawnmower", "$50.00"},
            { "2021-01-30", "kitchen", "blender", "$100.00"},
            { "2021-02-10", "kitchen", "chef's knife", "$25.00"},
            { "2021-02-11", "garden", "bbq", "$30.00"},
            { "2021-02-14", "bedRoom", "bed frame", "$40.00"},
           { "2021-02-15", "office", "monitor", "$60.00"},
           { "2021-02-16", "office", "desk", "$49.99"},
            { "2021-02-17", "kitchen", "table", "$200.00"},
            { "2021-02-18", "bedRoom", "lamp", "$10.00"},
            { "2021-02-18", "garden", "shovel", "$10.00"},
            { "2021-02-19", "other", "bicycle", "$200.00"}
        };
    
    return example;
    }
}
