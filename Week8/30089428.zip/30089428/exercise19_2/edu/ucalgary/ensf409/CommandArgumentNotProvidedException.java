package edu.ucalgary.ensf409;

public class CommandArgumentNotProvidedException extends Exception{

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public CommandArgumentNotProvidedException() {
        super();
    }
}
