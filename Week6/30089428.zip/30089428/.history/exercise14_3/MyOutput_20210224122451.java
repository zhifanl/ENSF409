import java.util.ArrayList;
import java.util.regex.*;
/**
 * @author Zhifan Li
 * @since 1.0
 * @version 1.0
 */

interface FormattedOutput{
	abstract String getFormatted();
}
enum Actions{
	END,
	ENABLE,
	START,
	TEST,
	DISABLE
}
enum Months{
	JAN {
		@Override
		public String toString() {
			return "January";
		}

		@Override
		public int toInt() {
			return 1;
		}

		@Override
		public String toLog() {
			return "Jan";
		}
	},
	FEB {
		@Override
		public String toString() {
			return "February";
		}

		@Override
		public int toInt() {
			return 2;
		}

		@Override
		public String toLog() {
			return "Feb";
		}
	},
	MAR {
		@Override
		public String toString() {
			return "March";
		}

		@Override
		public int toInt() {
			return 3;
		}

		@Override
		public String toLog() {
			return "Mar";
		}
	},
	APR {
		@Override
		public String toString() {
			return "April";
		}

		@Override
		public int toInt() {
			return 4;
		}

		@Override
		public String toLog() {
			return "Apr";
		}
	},
	MAY {
		@Override
		public String toString() {
			return "May";
		}

		@Override
		public int toInt() {
			return 5;
		}

		@Override
		public String toLog() {
			return "May";
		}
	},
	JUN {
		@Override
		public String toString() {
			return "June";
		}

		@Override
		public int toInt() {
			return 6;
		}

		@Override
		public String toLog() {
			return "Jun";
		}
	},
	JUL {
		@Override
		public String toString() {
			return "July";
		}

		@Override
		public int toInt() {
			return 7;
		}

		@Override
		public String toLog() {
			return "Jul";
		}
	},
	AUG {
		@Override
		public String toString() {
			return "August";
		}

		@Override
		public int toInt() {
			return 8;
		}

		@Override
		public String toLog() {
			return "Aug";
		}
	},
	SEP {
		@Override
		public String toString() {
			return "September";
		}

		@Override
		public int toInt() {
			return 9;
		}

		@Override
		public String toLog() {
			return "Sep";
		}
	},
	OCT {
		@Override
		public String toString() {
			return "October";
		}

		@Override
		public int toInt() {
			return 10;
		}

		@Override
		public String toLog() {
			return "Oct";
		}
	},
	NOV {
		@Override
		public String toString() {
			return "November";
		}

		@Override
		public int toInt() {
			return 11;
		}

		@Override
		public String toLog() {
			return "Nov";
		}
	},
	DEC {
		@Override
		public String toString() {
			return "December";
		}

		@Override
		public int toInt() {
			return 12;
		}

		@Override
		public String toLog() {
			return "Dec";
		}
	};

public abstract String toString();
public abstract int toInt();
public abstract String toLog();}

class IPv4 implements FormattedOutput{
	private String IP;
	private static String REGEX="^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$";
	
	//"81.220.24.207 - - [2/Mar/2020:10:05:44] \"END sprinkler (Visitor entrance - Building A)\"",

	private static Pattern PATTERN=Pattern.compile(REGEX);
	public IPv4(String ip){
		Matcher matcher=PATTERN.matcher(ip);
		if(matcher.find()){
			IP=ip;
		}
	}	
	public String getFormatted(){
		return "IPv4: "+IP;
	}
	public String getIP(){
		return IP;
	}
	public static String getRegex(){
		return REGEX;
	}
}
class Device implements FormattedOutput{
	private String DEVICE;
	private static String REGEX="\\s[a-zA-Z\\s]+\\s[(]";
	private static Pattern PATTERN=Pattern.compile(REGEX);
	public Device(String device){
		Matcher matcher=PATTERN.matcher(device);
		if(matcher.find()){
			DEVICE=device.trim();
			
		}
	}

	public String getFormatted(){
		return "Device: "+DEVICE;
	}
	public String getDevice(){
		return DEVICE;
	}
	public static String getRegex(){
		return REGEX;
	}
}
class Action implements FormattedOutput{
	private String ACTION;
	private static String REGEX="\\.[A-Z]+\\s";
	private static Pattern PATTERN=Pattern.compile(REGEX);
	public Action(String action){
		Matcher matcher=PATTERN.matcher(action);
		if(matcher.find()){
			switch(action){
				case "END":
				ACTION="END";
				break;
				case "ENABLE":
				ACTION="ENABLE";
				break;
				case "START":
				ACTION="START";
				break;
				case "TEST":
				ACTION="TEST";
				break;
				case "DISABLE":
				ACTION="DISABLE";
				break;
			}
		}
			

	}
	public String getFormatted(){
		return "Action: "+ACTION;

	}
	public String getAction(){
		return ACTION;
	}
	public static String getRegex(){
		return REGEX;
	}
}
class Location implements FormattedOutput{
	private String ROOM;
	private String BUILDING;
	private static String REGEX="[(][a-zA-z-\\s]+[)]";
	private static Pattern PATTERN=Pattern.compile(REGEX);
	public Location(String location){
		Matcher matcher=PATTERN.matcher(location);
		if(matcher.find()){
			location=location.replaceAll("[^0-9a-zA-Z ]", " ");
			String[] locationArray=location.split("\\s+");
			ROOM=locationArray[0];
			BUILDING=locationArray[1];
		}
	}
	public String getFormatted(){
		return "Room: "+ROOM+", Building: "+BUILDING;

	}
	public String getRoom(){
		return ROOM;

	}
	public String getBuilding(){
		return BUILDING;

	}
	public static String getRegex(){
		return REGEX;
	}
}
	//"81.220.24.207 - - [2/Mar/2020:10:05:44] \"END sprinkler (Visitor entrance - Building A)\"",

class DateTime implements FormattedOutput{
	private int DAY;
	private int MONTH;
	private int YEAR;
	private int HOUR;
	private int MINUTE;
	private int SECOND;
	private static String REGEX="\\[([0-9]{1,2})/([a-zA-Z]{3})/([0-9]{4}):([0-9]{1,2}):([0-9]{2}):([0-9]{2})]\\";
	//"81.220.24.207 - - [2/Mar/2020:10:05:44] \"END sprinkler (Visitor entrance - Building A)\""

	private static Pattern PATTERN=Pattern.compile(REGEX);
	public DateTime(String datetime){
		Matcher matcher=PATTERN.matcher(datetime);
		if(matcher.find()){
			datetime=datetime.replaceAll("[^0-9a-zA-Z ]", " ");
			String[] timeArray=datetime.split("\\s+");
			DAY=Integer.parseInt(timeArray[0]);
			switch(timeArray[1]){
				case "Jan":
				MONTH=1;
				break;
				case "Feb":
				MONTH=2;
				break;
				case "Mar":
				MONTH=3;
				break;
				case "Apr":
				MONTH=4;
				break;
				case "May":
				MONTH=5;
				break;
				case "Jun":
				MONTH=6;
				break;
				case "Jul":
				MONTH=7;
				break;
				case "Aug":
				MONTH=8;
				break;
				case "Sep":
				MONTH=9;
				break;
				case "Oct":
				MONTH=10;
				break;
				case "Nov":
				MONTH=11;
				break;
				case "Dec":
				MONTH=12;
				break;
			}
			//MONTH=timeArray[1];
			YEAR=Integer.parseInt(timeArray[2]);
			HOUR=Integer.parseInt(timeArray[3]);
			MINUTE=Integer.parseInt(timeArray[4]);
			SECOND=Integer.parseInt(timeArray[5]);
		}
	}
	public String getFormatted(){
		
		String a="Day: "+DAY+", "+"Month: "+monthToString()+", ";
		a+="Year: "+YEAR+", ";
		a+="Hour: "+HOUR+", "+"Minute: "+MINUTE+", "+"Second: "+SECOND;

		return a;
	}
	public String monthToString(){
		String namedMonth=null;
		switch(MONTH){
			case 1:
			namedMonth="January";
			break;
			case 2:
			namedMonth="February";
			break;
			case 3:
			namedMonth="March";
			break;
			case 4:
			namedMonth="April";
			break;
			case 5:
			namedMonth="May";
			break;
			case 6:
			namedMonth="June";
			break;
			case 7:
			namedMonth="July";
			break;
			case 8:
			namedMonth="August";
			break;
			case 9:
			namedMonth="September";
			break;
			case 10:
			namedMonth="October";
			break;
			case 11:
			namedMonth="November";
			break;
			case 12:
			namedMonth="December";
			break;
		}
		return namedMonth;
	}
	public int getDay(){
		return DAY;
	}
	public int getMonth(){
		return MONTH;
	}
	public int getYear(){
		return YEAR;
	}
	public int getHour(){
		return HOUR;
	}
	public int getMinute(){
		return MINUTE;
	}
	public int getSecond(){
		return SECOND;
	}
	public static String getRegex(){
		return REGEX;
	}

}
class ParseLine{
	private String LOGLINE;
	private Location LOCATION;
	private Device DEVICE;
	private Action ACTION;
	private DateTime DATETIME;
	private IPv4 IPV4;
	public ParseLine(String line){

		System.out.println(line.substring(0,line.indexOf("-")-1));
		IPV4=new IPv4(line.substring(0,line.indexOf("-")-1));
	
		
		int secondStartIndex=line.indexOf("[");
		int secondEndIndex=line.indexOf('\\')+1;
		System.out.println(line.substring(secondStartIndex, secondEndIndex));
		
		DATETIME=new DateTime(line.substring(secondStartIndex, secondEndIndex));
		int thirdStartIndex=line.indexOf("\"")+1;
		String newString=line.substring(thirdStartIndex);
		int thirdEndIndex=newString.indexOf(" ");
		ACTION=new Action(newString.substring(0, thirdEndIndex));
		newString=newString.substring(thirdEndIndex+1);
		int fourthEndIndex=newString.indexOf(" ");
		DEVICE=new Device(newString.substring(0, fourthEndIndex));
		newString=newString.substring(fourthEndIndex+2);
		int fifthEndIndex=newString.indexOf(")");
		LOCATION=new Location(newString.substring(0, fifthEndIndex));
		LOGLINE=IPV4.getIP()+" - - ["+DATETIME.getDay()+"/"+DATETIME.monthToString().substring(0,4)+"/";
		LOGLINE+=DATETIME.getYear()+":"+checkSpaceInDate(DATETIME.getHour())+":";
		LOGLINE+=checkSpaceInDate(DATETIME.getMinute())+":"+checkSpaceInDate(DATETIME.getSecond())+"] ";
		LOGLINE+="\""+ACTION.getAction()+" "+DEVICE.getDevice()+" ("+LOCATION.getRoom()+" - "+LOCATION.getBuilding();
		LOGLINE+=")\"";
		
	}
	public IPv4 getIPv4(){
		return IPV4;
	}
	public String getLogLine(){
		
		return LOGLINE;
	}
	private String checkSpaceInDate(int time){
		if(String.valueOf(time).length()==1){
			String temp="0"+time;
			return temp;
		}else{
		return String.valueOf(time);}
	}
	public Location getLocation(){
		return LOCATION;
	}
	public Device getDevice(){
		return DEVICE;
	}
	public Action getAction(){
		return ACTION;
	}
	public DateTime getDateTime(){
		return DATETIME;
	}
}

class ParseLogfile{
	private ArrayList<ParseLine> log;
	public ParseLogfile(String[] array){
		log=new ArrayList<>();

		//check length
		for(int i=0;i<array.length;i++){
			ParseLine temp=new ParseLine(array[i]);
			System.out.println(temp.getLogLine());
			
			log.add(temp);

		}
		
	}
	public ParseLine getLine(int index){
		ParseLine object=log.get(index);
		return object;
	}
	public ArrayList<ParseLine> getLog(){
		return log;
	}
}


public class MyOutput {
	public static void main(String args[]) {	
		String[] exampleLog = exampleLog();

		var logfile = new ParseLogfile(exampleLog);
		var line = logfile.getLine(0);
		System.out.println("Log line 0: " + line.getLogLine());

		var ip = line.getIPv4();
		System.out.println("IPv4: "+ip.getIP());
		
		var dt = line.getDateTime();
		System.out.println("Day: "+dt.getDay());
		System.out.println("Month: "+dt.getMonth());
		System.out.println("Month (named): "+dt.monthToString());
		System.out.println("Year: "+dt.getYear());
		System.out.println("Hour: "+dt.getHour());
		System.out.println("Minute: "+dt.getMinute());
		System.out.println("Second: "+dt.getSecond());

		var act = line.getAction();
		System.out.println("Action: "+act.getAction());

		var dev = line.getDevice();
		System.out.println("Device: "+dev.getDevice());

		var loc = line.getLocation();
		System.out.println("Room: "+loc.getRoom());
		System.out.println("Building: "+loc.getBuilding());

		System.out.println();
		line = logfile.getLine(6);
		System.out.println("Log line 6: " + line.getLogLine());
		System.out.println(line.getIPv4().getFormatted());
		System.out.println(line.getDateTime().getFormatted());
		System.out.println(line.getAction().getFormatted());
		System.out.println(line.getDevice().getFormatted());
		System.out.println(line.getLocation().getFormatted());

		System.out.println("\nExample of toLog() output: " + Months.AUG.toLog());
		System.out.println("\nExample regex (for DateTime): "+dt.getRegex());
	}


	// Contains example data 
	public static String[] exampleLog() {
		String[] log = {
"81.220.24.207 - - [2/Mar/2020:10:05:44] \"END sprinkler (Visitor entrance - Building A)\"",
"81.220.24.207 - - [2/Mar/2020:10:05:26] \"ENABLE cooling system (Secured room - Building A)\"",
"81.220.24.207 - - [2/Mar/2020:10:05:39] \"START heating system (Hall - Central)\"",
"81.220.24.207 - - [2/Mar/2020:10:05:52] \"ENABLE door lock (Visitor entrance - Building B)\"",
"81.220.24.207 - - [2/Mar/2020:10:05:21] \"TEST cooling system (Entrance - Building B)\"",
"66.249.73.135 - - [17/May/2020:01:05:17] \"TEST fan (Secured room - Airport location)\"",
"46.105.14.53 - - [17/May/2020:11:05:42] \"TEST cooling system (Secured room - Airport location)\"",
"218.30.103.62 - - [17/May/2020:11:05:11] \"START sprinkler (Secured room - Airport location)\"",
"218.30.103.62 - - [17/May/2020:11:05:46] \"DISABLE fan (Control room - Central)\"",
"218.30.103.62 - - [17/May/2020:11:05:45] \"START door lock (Secured room - Building A)\"",
"66.249.73.135 - - [27/Jun/2020:11:05:31] \"TEST sprinkler (Hall - Building B)\""};
		return log;
	}
}

